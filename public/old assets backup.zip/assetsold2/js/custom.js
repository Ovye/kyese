////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// jQuery
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//var baseUrl = $('#_url').val();
var automaticGeoLocation = false;
var resizeId;
let screenWidth = $(window).width();

$(document).ready(function ($) {
    "use strict";

//  Geo Location button

    if ($(".geo-location").length > 0 && $(".map").length === 0) {
        $("body").append("<div id='map-helper' style='display: none'></div>");
        var map = new google.maps.Map(document.getElementById("map-helper"));
        autoComplete(map);
    }

//  Selectize hack for disabling search

    var prevSetup = Selectize.prototype.setup;
    Selectize.prototype.setup = function () {
        prevSetup.call(this);
        this.$control_input.prop('readonly', false);
    };

//  Selectize

    var select = $(".selectized");
    if (select.length > 0 ) {
        select.selectize({
            onDropdownOpen: dropdownOpen,
            onDropdownClose: dropdownClose,
            allowEmptyOption: true,
            onChange: function (value) {
                return value !== '' ? $('.ky-select-wrap label.error').addClass('ky-selected') : $('.ky-select-wrap label.error').removeClass('ky-selected');
            }
        });
    }

    function dropdownOpen($dropdown) {
        $dropdown.addClass("opening");
    }

    function dropdownClose($dropdown) {
        $dropdown.removeClass("opening");
    }

//  Disable inputs in the non-active tab

    $(".form-slide:not(.active) input, .form-slide:not(.active) select, .form-slide:not(.active) textarea").prop("disabled", true);

//  Change tab button

    $(".change-tab").on("change", function () {
        var parameters = $(this).data("selectize").items[0];
        var changeTarget = $("#" + $(this).attr("data-change-tab-target"));
        var slide = changeTarget.find(".form-slide");
        if (parameters === "") {
            slide.removeClass("active");
            slide.first().addClass("default");
            changeTarget.find("input").prop("disabled", true);
            changeTarget.find("select").prop("disabled", true);
            changeTarget.find("textarea").prop("disabled", true);
        }
        else {
            slide.removeClass("default");
            slide.removeClass("active");
            changeTarget.find("input").prop("disabled", true);
            changeTarget.find("select").prop("disabled", true);
            changeTarget.find("textarea").prop("disabled", true);
            changeTarget.find("#" + parameters).addClass("active");
            changeTarget.find("#" + parameters + " input").prop("disabled", false);
            changeTarget.find("#" + parameters + " textarea").prop("disabled", false);
            changeTarget.find("#" + parameters + " select").prop("disabled", false);
        }
    });

    $(".box").each(function () {
        if ($(this).find(".background .background-image").length) {
            $(this).css("background-color", "transparent");
        }
    });

//  Star Rating

    $(".rating").each(function () {
        for (var i = 0; i < 5; i++) {
            if (i < $(this).attr("data-rating")) {
                $(this).append("<i class='active fa fa-star'></i>")
            }
            else {
                $(this).append("<i class='fa fa-star'></i>")
            }
        }
    });

//  Button for class changing

    $(".change-class").on("click", function (e) {
        e.preventDefault();
        var parentClass = $("." + $(this).attr("data-parent-class"));
        parentClass.removeClass($(this).attr("data-change-from-class"));
        parentClass.addClass($(this).attr("data-change-to-class"));
        $(this).parent().find(".change-class").removeClass("active");
        $(this).addClass("active");
        readMore();
    });

    if ($(".masonry").length) {
        $(".items.masonry").masonry({
            itemSelector: ".item",
            transitionDuration: 0
        });
    }

    $(".ribbon-featured").each(function () {
        var thisText = $(this).text();
        $(this).html("");
        $(this).append(
            "<div class='ribbon-start'></div>" +
            "<div class='ribbon-content'>" + thisText + "</div>" +
            "<div class='ribbon-end'>" +
            "<figure class='ribbon-shadow'></figure>" +
            "</div>"
        );
    });

//  File input styling

    if ($("input[type=file].with-preview").length) {
        $("input.file-upload-input").MultiFile({
            list: ".file-upload-previews"
        });
    }

    $(".single-file-input input[type=file]").change(function () {
        previewImage(this);
    });

    $(".has-child a[href='#'].nav-link").on("click", function (e) {
        e.preventDefault();
        if (!$(this).parent().hasClass("hover")) {
            $(this).parent().addClass("hover");
        }
        else {
            $(this).parent().removeClass("hover");
        }
    });

    if ($(".owl-carousel").length) {
        var galleryCarousel = $(".gallery-carousel");

        galleryCarousel.owlCarousel({
            loop: false,
            margin: 0,
            nav: true,
            items: 1,
            navText: ["<i class='fa fa-chevron-left'></i>", "<i class='fa fa-chevron-right'></i>"],
            autoHeight: true,
            dots: false
        });

        $(".tabs-slider").owlCarousel({
            loop: false,
            margin: 0,
            nav: false,
            items: 1,
            autoHeight: true,
            dots: false,
            mouseDrag: true,
            touchDrag: false,
            pullDrag: false,
            freeDrag: false
        });

        $(".full-width-carousel").owlCarousel({
            loop: true,
            margin: 10,
            nav: true,
            items: 3,
            navText: ["<i class='fa fa-chevron-left'></i>", "<i class='fa fa-chevron-right'></i>"],
            autoHeight: false,
            center: true,
            dots: false,
            autoWidth: true,
            responsive: {
                768: {
                    items: 3
                },
                0: {
                    items: 1,
                    center: false,
                    margin: 0,
                    autoWidth: false
                }
            }
        });

        $('.categories-carousel').owlCarousel({
            loop: false,
            animateOut: 'slideOutDown',
            animateIn: 'flipInX',
            margin: 10,
            nav: true,
            touchDrag: true,
            mouseDrag: true,
            navText: ["<i class='sl fa sl-icon-arrow-left'></i>", "<i class='sl fa sl-icon-arrow-right'></i>"],
            dots: false,
            autoHeight: true,
            responsiveClass: true,
            responsive: {
                0: {
                    items: 2
                },
                600: {
                    items: 3
                },
                1000: {
                    items: 5
                }
            }
        });

        //Recent ads

        $('.recent-ads-carousel').owlCarousel({
            loop: false,
            margin: 10,
            nav: true,
            touchDrag: true,
            mouseDrag: true,
            navText: ["<i class='sl fa sl-icon-arrow-left'></i>", "<i class='sl fa sl-icon-arrow-right'></i>"],
            dots: false,
            autoHeight: true,
            responsiveClass: true,
            responsive: {
                0: {
                    items: 1,
                    loop: false
                },
                520: {
                    items: 2,
                    loop: false
                },
                1024: {
                    items: 3,
                    autoplay: true,
                    autoplayTimeout: 5000,
                    autoplayHoverPause: true,
                    loop: true
                },
                1200: {
                    items: 4,
                    autoplay: false,
                    autoplayTimeout: 5000,
                    autoplayHoverPause: true,
                    loop: false
                }
            }
        });

        $(".gallery-carousel-thumbs").owlCarousel({
            loop: false,
            margin: 20,
            nav: false,
            dots: true,
            items: 5,
            URLhashListener: true
        });

        $("a.owl-thumb").on("click", function () {
            $("a.owl-thumb").removeClass("active-thumb");
            $(this).addClass("active-thumb");
        });

        galleryCarousel.on('translated.owl.carousel', function () {
            var hash = $(this).find(".active").find("img").attr("data-hash");
            $(".gallery-carousel-thumbs").find("a[href='#" + hash + "']").trigger("click");
        });
    }

//  Bootstrap tooltip initialization

    $('[data-toggle="tooltip"]').tooltip();

//  iCheck

    $("input[type=checkbox], input[type=radio]").iCheck({
        checkboxClass: 'icheckbox_square-green',
        radioClass: 'iradio_square-green',
    });

    let framedInputRadio = $(".framed input[type=radio]");
    framedInputRadio.on('ifChecked', function(){
        $(this).closest(".framed").addClass("active");
    });
    framedInputRadio.on('ifUnchecked', function(){
        $(this).closest(".framed").removeClass("active");
    });

//  "img" into "background-image" transfer

    $("[data-background-image]").each(function () {
        $(this).css("background-image", "url(" + $(this).attr("data-background-image") + ")");
    });

    $(".background-image").each(function () {
        $(this).css("background-image", "url(" + $(this).find("img").attr("src") + ")");
    });

//  Custom background color

    $("[data-background-color]").each(function () {
        $(this).css("background-color", $(this).attr("data-background-color"));
    });

//  Form Validation

    $(".form.email .btn[type='submit']").on("click", function (e) {
        var button = $(this);
        var form = $(this).closest("form");
        button.prepend("<div class='status'></div>");
        form.validate({
            submitHandler: function () {
                $.post("assets/php/email.php", form.serialize(), function (response) {
                    button.find(".status").append(response);
                    form.addClass("submitted");
                });
                return false;
            }
        });
    });

//  Read More

    readMore();

});

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Functions
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Read More

function readMore() {
    $(".read-more").each(function () {
        var readMoreLink = $(this).attr("data-read-more-link-more");
        var readLessLink = $(this).attr("data-read-more-link-less");
        var collapseHeight = $(this).find(".item:first").height() + parseInt($(this).find(".item:first").css("margin-bottom"), 10);
        $(".read-more").readmore({
            moreLink: '<div class="center"><a href="#" class="btn btn-primary btn-rounded btn-framed">' + readMoreLink + '</a></div>',
            lessLink: '<div class="center"><a href="#" class="btn btn-primary btn-rounded btn-framed">' + readLessLink + '</a></div>',
            collapsedHeight: 500
        });
    });
}

// Google Map

function simpleMap(latitude, longitude, markerImage, mapTheme, mapElement, markerDrag) {
    if (!markerDrag) {
        markerDrag = false;
    }
    if (mapTheme === "light") {
        var mapStyles = [{
            "featureType": "administrative.locality",
            "elementType": "all",
            "stylers": [{"hue": "#c79c60"}, {"saturation": 7}, {"lightness": 19}, {"visibility": "on"}]
        }, {
            "featureType": "landscape",
            "elementType": "all",
            "stylers": [{"hue": "#ffffff"}, {"saturation": -100}, {"lightness": 100}, {"visibility": "simplified"}]
        }, {
            "featureType": "poi",
            "elementType": "all",
            "stylers": [{"hue": "#ffffff"}, {"saturation": -100}, {"lightness": 100}, {"visibility": "off"}]
        }, {
            "featureType": "road",
            "elementType": "geometry",
            "stylers": [{"hue": "#c79c60"}, {"saturation": -52}, {"lightness": -10}, {"visibility": "simplified"}]
        }, {
            "featureType": "road",
            "elementType": "labels",
            "stylers": [{"hue": "#c79c60"}, {"saturation": -93}, {"lightness": 31}, {"visibility": "on"}]
        }, {
            "featureType": "road.arterial",
            "elementType": "labels",
            "stylers": [{"hue": "#c79c60"}, {"saturation": -93}, {"lightness": -2}, {"visibility": "simplified"}]
        }, {
            "featureType": "road.local",
            "elementType": "geometry",
            "stylers": [{"hue": "#c79c60"}, {"saturation": -52}, {"lightness": -10}, {"visibility": "simplified"}]
        }, {
            "featureType": "transit",
            "elementType": "all",
            "stylers": [{"hue": "#c79c60"}, {"saturation": 10}, {"lightness": 69}, {"visibility": "on"}]
        }, {
            "featureType": "water",
            "elementType": "all",
            "stylers": [{"hue": "#c79c60"}, {"saturation": -78}, {"lightness": 67}, {"visibility": "simplified"}]
        }];
    }
    else if (mapTheme === "dark") {
        mapStyles = [{
            "featureType": "all",
            "elementType": "labels.text.fill",
            "stylers": [{"saturation": 36}, {"color": "#000000"}, {"lightness": 40}]
        }, {
            "featureType": "all",
            "elementType": "labels.text.stroke",
            "stylers": [{"visibility": "on"}, {"color": "#000000"}, {"lightness": 16}]
        }, {
            "featureType": "all",
            "elementType": "labels.icon",
            "stylers": [{"visibility": "off"}]
        }, {
            "featureType": "administrative",
            "elementType": "geometry.fill",
            "stylers": [{"color": "#000000"}, {"lightness": 20}]
        }, {
            "featureType": "administrative",
            "elementType": "geometry.stroke",
            "stylers": [{"color": "#000000"}, {"lightness": 17}, {"weight": 1.2}]
        }, {
            "featureType": "landscape",
            "elementType": "geometry",
            "stylers": [{"color": "#000000"}, {"lightness": 20}]
        }, {
            "featureType": "poi",
            "elementType": "geometry",
            "stylers": [{"color": "#000000"}, {"lightness": 21}]
        }, {
            "featureType": "road.highway",
            "elementType": "geometry.fill",
            "stylers": [{"color": "#000000"}, {"lightness": 17}]
        }, {
            "featureType": "road.highway",
            "elementType": "geometry.stroke",
            "stylers": [{"color": "#000000"}, {"lightness": 29}, {"weight": 0.2}]
        }, {
            "featureType": "road.arterial",
            "elementType": "geometry",
            "stylers": [{"color": "#000000"}, {"lightness": 18}]
        }, {
            "featureType": "road.local",
            "elementType": "geometry",
            "stylers": [{"color": "#000000"}, {"lightness": 16}]
        }, {
            "featureType": "transit",
            "elementType": "geometry",
            "stylers": [{"color": "#000000"}, {"lightness": 19}]
        }, {"featureType": "water", "elementType": "geometry", "stylers": [{"color": "#000000"}, {"lightness": 17}]}]
    }
    var mapCenter = new google.maps.LatLng(latitude, longitude);
    var mapOptions = {
        zoom: 13,
        center: mapCenter,
        disableDefaultUI: false,
        scrollwheel: false,
        styles: mapStyles
    };
    var element = document.getElementById(mapElement);
    var map = new google.maps.Map(element, mapOptions);
    var marker = new google.maps.Marker({
        position: new google.maps.LatLng(latitude, longitude),
        map: map,
        icon: markerImage,
        draggable: markerDrag
    });

    google.maps.event.addListener(marker, 'dragend', function () {
        var latitudeInput = $('#latitude');
        var longitudeInput = $("#longitude");
        if (latitudeInput.length) {
            latitudeInput.val(marker.getPosition().lat());
        }
        if (longitudeInput.length) {
            longitudeInput.val(marker.getPosition().lng());
        }
    });

    autoComplete(map, marker);

}

//Autocomplete ---------------------------------------------------------------------------------------------------------

function autoComplete(map, marker) {
    if ($("#input-location").length) {
        if (!map) {
            map = new google.maps.Map(document.getElementById("input-location"));
        }
        var mapCenter;
        var input = document.getElementById('input-location');
        var autocomplete = new google.maps.places.Autocomplete(input);
        autocomplete.bindTo('bounds', map);
        google.maps.event.addListener(autocomplete, 'place_changed', function () {
            var place = autocomplete.getPlace();
            if (!place.geometry) {
                return;
            }
            if (place.geometry.viewport) {
                map.fitBounds(place.geometry.viewport);
            } else {
                map.setCenter(place.geometry.location);
                map.setZoom(17);
            }
            mapCenter = place.geometry.location;
            if (marker) {
                marker.setPosition(place.geometry.location);
                marker.setVisible(true);
                $('#latitude').val(marker.getPosition().lat());
                $('#longitude').val(marker.getPosition().lng());
            }
            var address = '';
            if (place.address_components) {
                address = [
                    (place.address_components[0] && place.address_components[0].short_name || ''),
                    (place.address_components[1] && place.address_components[1].short_name || ''),
                    (place.address_components[2] && place.address_components[2].short_name || '')
                ].join(' ');
            }
        });

        $('.geo-location').on("click", function (e) {
            e.preventDefault();
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(success);
            } else {
                console.log('Geo Location is not supported');
            }
        });

        function success(position) {
            var locationCenter = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
            map.setCenter(locationCenter);
            map.setZoom(14);
            if (marker) {
                marker.setPosition(locationCenter);
            }

            var geocoder = new google.maps.Geocoder();
            geocoder.geocode({
                "latLng": locationCenter
            }, function (results, status) {
                if (status === google.maps.GeocoderStatus.OK) {
                    var lat = results[0].geometry.location.lat(),
                        lng = results[0].geometry.location.lng(),
                        placeName = results[0].address_components[0].long_name,
                        latlng = new google.maps.LatLng(lat, lng);

                    $("#input-location").val(results[0].formatted_address);
                    var latitudeInput = $('#latitude');
                    var longitudeInput = $("#longitude");
                    if (latitudeInput.length) {
                        latitudeInput.val(marker.getPosition().lat());
                    }
                    if (longitudeInput.length) {
                        longitudeInput.val(marker.getPosition().lng());
                    }
                }
            });

        }
    }
}

function previewImage(input) {
    var ext = $(input).val().split('.').pop().toLowerCase();
    if (input.files && input.files[0] && $.inArray(ext, ['gif', 'png', 'jpg', 'jpeg']) === -1) {
        kNotify({
            type: 'danger',
            title: 'Invalid extension!',
            message: 'Only images can be selected',
            progress: true,
            timer: 3000,
            from: 'bottom'
        });
    }
    else {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                let target = e.target;
                $(input).parents(".profile-image").find(".image").attr("style", "background-image: url('" + e.target.result + "');");
                let file = input.files[0];
                $('.single-file-name').html(`(${formatBytes(file.size)}) - ${file.name}`);
            };
            reader.readAsDataURL(input.files[0]);
        }
    }
}

// Custom k-contents

$(function () {

    // Select all elements with data-toggle="popover" in the document

    $('[data-toggle="popover"]').popover();

    let kFormPopoverOptions;
    //  if(screenWidth > 760) {
    //      kFormPopoverOptions = {trigger: 'hover', container: 'body', placement: 'right'};
    //  } else {
    //      kFormPopoverOptions = {trigger: 'focus', container: 'body', placement: 'bottom'};
    //  }

    // $('.k-form-popover').tooltip(kFormPopoverOptions);


    let pxShow = 450;
    let scrollSpeed = 1000;
    let backToTop = $('#backtotop');
    $(window).scroll(function () {
        if ($(window).scrollTop() >= pxShow) {
            backToTop.addClass('visible');
        } else {
            backToTop.removeClass('visible');
        }
    });
    backToTop.on('click', function () {
        $('html, body').animate({
            scrollTop: 0
        }, scrollSpeed);
        return false;
    });

    // Show sticky search button only at a certain height

    let stickySearchBtn = $(".k-sticky-search-btn");
    $(window).scroll(function () {
        if ($(window).scrollTop() >= 250) {
            stickySearchBtn.addClass('visible');
        } else {
            stickySearchBtn.removeClass('visible');
        }
    });

    stickySearchBtn.on('click', function () {
        $('html, body').animate({
            scrollTop: 120
        }, scrollSpeed);
        let searchForm = $('#collapseMainSearchForm');
        searchForm.addClass('show animated bounceIn');
        return false;
    });


    function isTouchDevice() {
        return true == ("ontouchstart" in window || window.DocumentTouch && document instanceof DocumentTouch);
    }

    /**
     * Create a default validator on forms.
     * @formCLass k-form-validate
     */
    $('.k-form-validate').validate({
        validClass: 'k-has-success'
    });

    $(document).on('click', '.sticky-top-search-menu.dropdown-menu', function (e) {
        e.stopPropagation();
    });


});

/**
 * Build a new $.notify bootstrap plugin function (kNotify) for easy utilization
 * @param options | Objects
 */

function kNotify(options) {
    if (objectLength(options) > 0) {
        let alertPadding = options.padding === null ? 0 : options.padding;
        let icon = options.icon !== null ? options.icon : null;
        let type = options.type;
        let message = options.message;
        let progress = options.progress !== null ? options.progress : null;
        let link = options.link;
        let target = options.target !== '' ? options.target : null;
        let position = options.position !== null ? options.position : null;
        let delay = options.delay !== null ? options.delay : 5000;
        let _title;


        if (type === 'warning') {
            icon = options.icon ? options.icon + ' k-notify-icon' : 'fa fa-warning warning k-notify-icon';
            _title = 'Warning';
        }

        if (type === 'success') {
            icon = options.icon ? options.icon + ' k-notify-icon' : 'sl sl-icon-check success k-notify-icon';
            _title = 'Success';
        }
        if (type === 'danger') {
            icon = options.icon ? options.icon + ' k-notify-icon' : 'sl sl-icon-close danger k-notify-icon';
            _title = 'Error';
        }
        if (type === 'info') {
            icon = options.icon ? options.icon + ' k-notify-icon' : 'sl sl-icon-info info k-notify-icon';
            _title = 'Notice';
        }

        let title = options.title ? options.title : _title;

        $.notify({
            // options
            icon: icon,
            title: title,
            message: message,
            url: link,
            target: target
        }, {
            // settings
            element: 'body',
            position: position,
            type: type,
            allow_dismiss: options.dismiss !== '' ? options.dismiss : true,
            newest_on_top: options.newest_first !== '' ? options.newest_first : true,
            showProgressbar: true,
            placement: {
                from: options.from !== '' ? options.from : 'top',
                align: options.align !== '' ? options.align : 'right'
            },
            offset: options.offset !== '' ? options.offset : 20,
            spacing: options.spacing !== '' ? options.spacing : 10,
            z_index: 1031,
            delay: delay,
            timer: options.timer !== '' ? options.timer : 1000,
            url_target: options.url_target !== '' ? options.url_target : '_blank',
            mouse_over: options.mouse_over ? options.mouse_over : 'pause',
            animate: options.animate ? options.animate : {
                enter: 'animated rubberBand',
                exit: 'animated fadeOutRight'
            },
            onShow: options.onShow !== '' ? options.onShow : null,
            onShown: options.onShown !== '' ? options.onShown : null,
            onClose: options.onClose !== '' ? options.onClose : null,
            onClosed: options.onClosed !== '' ? options.onClosed : null,
            icon_type: 'class',
            template: '<div data-notify="container" class="col-xs-12 col-sm-7 col-md-6 col-lg-5 col-xl-4 k-notify-wrap p-' + alertPadding + ' alert alert-{0}" role="alert">' +
            '<a  aria-hidden="true" class="close" data-notify="dismiss"><i uk-icon="icon: close"></i></a>' +
            '<span data-notify="icon"></span> ' +
            '<span data-notify="title" class="font-weight-bold d-inline-block uk-text-truncate">' + title + '</span><br/> ' +
            '<span data-notify="message" class="k-notify-message">{2}</span>' +
            '<div class="progress" data-notify="progressbar">' +
            '<div class="progress-bar progress-bar-striped progress-bar-animated bg-{0}" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%;"></div>' +
            '</div>' +
            '<a href="{3}" target="{4}" data-notify="url"></a>' +
            '</div>'
        });

    }

}


/**
 * A simple object counter
 * @param object
 * @returns {number}
 * @constructor
 */

function objectLength(object) {
    let length = 0;
    for (let key in object) {
        if (object.hasOwnProperty(key)) {
            ++length;
        }
    }
    return length;
}

function moneyFormat(number) {
    let num = number.toString();
    return num.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
}

function formatBytes(bytes, decimals) {
    if (bytes === 0) return '0 Bytes';
    if (bytes === 1) return '1 Byte';
    if (bytes === -1) return '-1 Byte';
    let k = 1024,
        dm = decimals || 2,
        sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'],
        i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

/**
 * Manipulate K_password
 */


function showHidePassword() {
    $('.kp-control').on('click', function (e) {
        e.preventDefault();
        let control_id = this.id;
        let k_pass_target = $(`[data-kp=${control_id}`);
        let input_field_value = k_pass_target.val();
        let input_field_type = k_pass_target.attr('type');

        if (input_field_value != '') {
            if (input_field_type == 'password') {
                k_pass_target.attr('type', 'text');
                $(this).html(`<i class="fa fa-eye-slash"></i>`);
            }
            else if (input_field_type == 'text') {
                k_pass_target.attr('type', 'password');
                $(this).html(`<i class="fa fa-eye"></i>`);
            }
        }
        // else {
        //     kNotify({
        //         type: 'danger',
        //         title: 'Empty password field',
        //         message: '<b>Sorry!!</b> You can only show or hide password when password field is not empty.',
        //         progress: true
        //     });
        // }

    });

}

showHidePassword(); //Activate show/hide password function









